import os
import httpx

class ContentProvider:
    async def generate(self, campaign: dict) -> dict:
        raise NotImplementedError

class TemplateProvider(ContentProvider):
    async def generate(self, campaign: dict) -> dict:
        name = campaign["name"]
        description = campaign.get("description") or f"A standout {campaign['kind'].lower()}"
        price = f" Price: {campaign['price']}." if campaign.get("price") else ""
        cta = campaign.get("call_to_action") or "Contact us to learn more."
        return {
            "main_ad": f"Discover {name}. {description}.{price} {cta}",
            "short_ad": f"{name} — made for what matters. {cta}",
            "instagram": f"✨ {name}\n\n{description}\n\n{cta}",
            "facebook": f"Meet {name}. {description}\n\n{cta}",
            "linkedin": f"Introducing {name}: {description} {cta}",
            "youtube_title": f"Discover {name}",
            "youtube_description": f"Take a closer look at {name}. {description}\n\n{cta}",
            "whatsapp": f"Hello! Sharing {name}: {description}. {cta}",
            "hashtags": "#Marketing #NewLaunch #DiscoverMore #LocalBusiness",
            "video_script": f"Introducing {name}. {description}. {cta}",
            "call_to_action": cta,
            "provider": "template"
        }

class OllamaProvider(ContentProvider):
    async def generate(self, campaign: dict) -> dict:
        base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
        model = os.getenv("OLLAMA_MODEL", "llama3.2")
        prompt = f"Create concise marketing copy as JSON with keys main_ad, short_ad, instagram, facebook, linkedin, youtube_title, youtube_description, whatsapp, hashtags, video_script, call_to_action. Campaign: {campaign}"
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(f"{base_url}/api/generate", json={"model": model, "prompt": prompt, "format": "json", "stream": False})
            response.raise_for_status()
            import json
            result = json.loads(response.json()["response"])
            result["provider"] = f"ollama:{model}"
            return result

def get_provider() -> ContentProvider:
    return OllamaProvider() if os.getenv("AI_PROVIDER", "template").lower() == "ollama" else TemplateProvider()
