from pydantic import BaseModel, Field

class CampaignInput(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    kind: str = "Product"
    description: str = ""
    features: str = ""
    price: str = ""
    target_audience: str = ""
    location: str = ""
    call_to_action: str = ""

class SceneInput(BaseModel):
    position: int = 0
    start_seconds: int = 0
    duration_seconds: int = 4
    media_id: int | None = None
    lines: list[str] = []
