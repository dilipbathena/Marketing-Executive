from datetime import datetime
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class Campaign(Base):
    __tablename__ = "campaigns"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    kind: Mapped[str] = mapped_column(String(60), default="Product")
    description: Mapped[str] = mapped_column(Text, default="")
    features: Mapped[str] = mapped_column(Text, default="")
    price: Mapped[str] = mapped_column(String(120), default="")
    target_audience: Mapped[str] = mapped_column(Text, default="")
    location: Mapped[str] = mapped_column(String(180), default="")
    call_to_action: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    media: Mapped[list["Media"]] = relationship(back_populates="campaign", cascade="all, delete-orphan")
    scenes: Mapped[list["Scene"]] = relationship(back_populates="campaign", cascade="all, delete-orphan", order_by="Scene.position")

class Media(Base):
    __tablename__ = "media"
    id: Mapped[int] = mapped_column(primary_key=True)
    campaign_id: Mapped[int] = mapped_column(ForeignKey("campaigns.id"))
    filename: Mapped[str] = mapped_column(String(255))
    original_name: Mapped[str] = mapped_column(String(255))
    mime_type: Mapped[str] = mapped_column(String(100), default="")
    campaign: Mapped[Campaign] = relationship(back_populates="media")

class Scene(Base):
    __tablename__ = "scenes"
    id: Mapped[int] = mapped_column(primary_key=True)
    campaign_id: Mapped[int] = mapped_column(ForeignKey("campaigns.id"))
    position: Mapped[int] = mapped_column(Integer, default=0)
    start_seconds: Mapped[int] = mapped_column(Integer, default=0)
    duration_seconds: Mapped[int] = mapped_column(Integer, default=4)
    media_id: Mapped[int | None] = mapped_column(ForeignKey("media.id"), nullable=True)
    lines_json: Mapped[str] = mapped_column(Text, default="[]")
    campaign: Mapped[Campaign] = relationship(back_populates="scenes")
