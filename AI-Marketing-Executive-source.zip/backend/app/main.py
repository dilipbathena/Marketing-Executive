import json, shutil, uuid
from pathlib import Path
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from .database import Base, engine, get_db
from .models import Campaign, Media, Scene
from .schemas import CampaignInput, SceneInput
from .services.content_provider import get_provider

Base.metadata.create_all(bind=engine)
UPLOAD_DIR = Path(__file__).resolve().parents[1] / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="AI Marketing Executive API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

def campaign_out(c: Campaign):
    return {"id": c.id, "name": c.name, "kind": c.kind, "description": c.description, "features": c.features, "price": c.price, "target_audience": c.target_audience, "location": c.location, "call_to_action": c.call_to_action, "created_at": c.created_at.isoformat(), "media": [{"id": m.id, "url": f"/uploads/{m.filename}", "original_name": m.original_name, "mime_type": m.mime_type} for m in c.media], "scenes": [{"id": s.id, "position": s.position, "start_seconds": s.start_seconds, "duration_seconds": s.duration_seconds, "media_id": s.media_id, "lines": json.loads(s.lines_json)} for s in c.scenes]}

@app.get("/api/health")
def health(): return {"status": "ok"}

@app.get("/api/campaigns")
def list_campaigns(db: Session = Depends(get_db)):
    return [campaign_out(c) for c in db.query(Campaign).order_by(Campaign.created_at.desc()).all()]

@app.post("/api/campaigns")
def create_campaign(data: CampaignInput, db: Session = Depends(get_db)):
    c = Campaign(**data.model_dump()); db.add(c); db.commit(); db.refresh(c); return campaign_out(c)

@app.get("/api/campaigns/{campaign_id}")
def get_campaign(campaign_id: int, db: Session = Depends(get_db)):
    c = db.get(Campaign, campaign_id)
    if not c: raise HTTPException(404, "Campaign not found")
    return campaign_out(c)

@app.put("/api/campaigns/{campaign_id}")
def update_campaign(campaign_id: int, data: CampaignInput, db: Session = Depends(get_db)):
    c = db.get(Campaign, campaign_id)
    if not c: raise HTTPException(404, "Campaign not found")
    for key, value in data.model_dump().items(): setattr(c, key, value)
    db.commit(); db.refresh(c); return campaign_out(c)

@app.post("/api/campaigns/{campaign_id}/media")
async def upload_media(campaign_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not db.get(Campaign, campaign_id): raise HTTPException(404, "Campaign not found")
    suffix = Path(file.filename or "upload").suffix
    stored = f"{uuid.uuid4().hex}{suffix}"
    with (UPLOAD_DIR / stored).open("wb") as destination: shutil.copyfileobj(file.file, destination)
    item = Media(campaign_id=campaign_id, filename=stored, original_name=file.filename or stored, mime_type=file.content_type or "")
    db.add(item); db.commit(); db.refresh(item)
    return {"id": item.id, "url": f"/uploads/{item.filename}", "original_name": item.original_name, "mime_type": item.mime_type}

@app.post("/api/campaigns/{campaign_id}/generate-content")
async def generate_content(campaign_id: int, db: Session = Depends(get_db)):
    c = db.get(Campaign, campaign_id)
    if not c: raise HTTPException(404, "Campaign not found")
    try: return await get_provider().generate(campaign_out(c))
    except Exception as error: raise HTTPException(502, f"Local AI provider unavailable: {error}")

@app.post("/api/campaigns/{campaign_id}/scenes")
def create_scene(campaign_id: int, data: SceneInput, db: Session = Depends(get_db)):
    if not db.get(Campaign, campaign_id): raise HTTPException(404, "Campaign not found")
    s = Scene(campaign_id=campaign_id, **data.model_dump(exclude={"lines"}), lines_json=json.dumps(data.lines))
    db.add(s); db.commit(); db.refresh(s); return {"id": s.id, **data.model_dump()}

@app.put("/api/scenes/{scene_id}")
def update_scene(scene_id: int, data: SceneInput, db: Session = Depends(get_db)):
    s = db.get(Scene, scene_id)
    if not s: raise HTTPException(404, "Scene not found")
    for key, value in data.model_dump(exclude={"lines"}).items(): setattr(s, key, value)
    s.lines_json = json.dumps(data.lines); db.commit(); return {"id": s.id, **data.model_dump()}

@app.post("/api/campaigns/{campaign_id}/storyboard/export")
def export_storyboard(campaign_id: int, db: Session = Depends(get_db)):
    c = db.get(Campaign, campaign_id)
    if not c: raise HTTPException(404, "Campaign not found")
    return {"ready_to_render": bool(shutil.which("ffmpeg")), "message": "FFmpeg rendering is scaffolded; this endpoint returns the storyboard export plan.", "scenes": campaign_out(c)["scenes"]}
