import "./globals.css";
export const metadata = { title: "AI Marketing Executive", description: "Local-first campaign studio" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
